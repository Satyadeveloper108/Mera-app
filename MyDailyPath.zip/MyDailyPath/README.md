# My Daily Path

A personal daily-life app for Android: daily tasks, one main goal per day with a streak, monthly goals,
a history of everything you completed, and an optional section for a photo of your Guru.
It works fully offline. There is no login, no server, no cloud account and no internet permission.
It contains nothing about money.

The app is written in Kotlin with Jetpack Compose, so the screens are Kotlin files and there are no XML layout files.
Data is stored on the phone with Room (tasks and goals) and DataStore (settings).

## Run it

1. Install [Android Studio](https://developer.android.com/studio) (Ladybug 2024.2 or newer).
2. Choose **File > Open** and select the `MyDailyPath` folder.
3. Wait for the Gradle sync to finish. It needs an internet connection once, to download the build tools and libraries.
   The finished app never uses the internet.
4. Connect an Android phone (Android 8.0 or newer, with USB debugging on) or start an emulator, then press **Run**.

To get an APK file to install yourself: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The debug APK is created in `app/build/outputs/apk/debug/`.

If Android Studio offers to update the Android Gradle Plugin or Gradle, you can accept.
If you prefer command-line builds, run `gradle wrapper` once in this folder to create `gradlew`.

## Change the name

- **Name inside the app**: you choose it on first launch, and can change it any time in **Settings > Rename app**.
- **Name under the launcher icon**: change `app_name` in `app/src/main/res/values/strings.xml`.
  Android does not allow this name to change while the app is running.

## How the main goal and streak work

- You choose one main goal for each day on the **Today** screen. A day has at most one main goal.
- Completing today's goal continues the streak if yesterday's goal was completed too.
- If a day is missed, the streak ends. The next time you complete a goal, the streak starts again at **1**.
- Completing the same day more than once never adds extra days. The streak is worked out from the set of days
  whose goal is completed, and the database update only changes a goal that is not already completed.
- While today's goal is still open, yesterday's streak still shows, because the day is not over yet.
- **Undo** reopens today's goal. A completed goal cannot be removed, so your history stays accurate.

The rules live in `StreakCalculator.kt` and are covered by `StreakCalculatorTest.kt`
(in Android Studio, right-click the test file and choose Run).

## Where your data is

Tasks, goals, streak history and settings are stored in the app's private storage on the phone.
Closing the app, restarting the phone or updating the app keeps them.
Uninstalling the app removes them.
The Guru photo is copied into the app's private storage, so it keeps working even if the original is deleted from the gallery.

## Project map

Every file, with its exact path from the project root.

### Build files

| Path | Purpose |
| --- | --- |
| `settings.gradle.kts` | Project name and the `:app` module; where Gradle downloads libraries from |
| `build.gradle.kts` | Top-level build file (plugin declarations) |
| `gradle.properties` | Gradle and AndroidX settings |
| `gradle/libs.versions.toml` | Version catalog: every library and plugin version in one place |
| `gradle/wrapper/gradle-wrapper.properties` | Tells Android Studio which Gradle version to download |
| `.gitignore` | Files Git should ignore |
| `app/build.gradle.kts` | App module: SDK versions, Compose, Room, DataStore and other dependencies |
| `app/proguard-rules.pro` | Release shrinker rules (shrinking is off) |
| `app/src/main/AndroidManifest.xml` | App declaration. No permissions are requested |

### Resources

| Path | Purpose |
| --- | --- |
| `app/src/main/res/drawable/ic_launcher_foreground.xml` | Launcher icon artwork: a ring of mala beads with a check mark |
| `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` | Adaptive launcher icon definition |
| `app/src/main/res/values-night/colors.xml` | Window and launcher-icon background colours (dark) |
| `app/src/main/res/values-night/themes.xml` | Window theme before Compose draws (dark) |
| `app/src/main/res/values/colors.xml` | Window and launcher-icon background colours (light) |
| `app/src/main/res/values/strings.xml` | `app_name`: the name under the launcher icon |
| `app/src/main/res/values/themes.xml` | Window theme before Compose draws (light) |

### Kotlin source

| Path | Purpose |
| --- | --- |
| `app/src/main/java/com/personal/dailypath/AppContainer.kt` | Creates and shares the database, settings and photo storage |
| `app/src/main/java/com/personal/dailypath/LifeApp.kt` | Application class; creates the app container |
| `app/src/main/java/com/personal/dailypath/MainActivity.kt` | The single activity: theme, welcome screen or app, midnight roll-over |
| `app/src/main/java/com/personal/dailypath/data/LifeRepository.kt` | All reads and writes for tasks and goals |
| `app/src/main/java/com/personal/dailypath/data/local/AppDatabase.kt` | The Room database |
| `app/src/main/java/com/personal/dailypath/data/local/Converters.kt` | Room converters for dates and months |
| `app/src/main/java/com/personal/dailypath/data/local/Daos.kt` | Database queries for tasks, goals and monthly goals |
| `app/src/main/java/com/personal/dailypath/data/local/Entities.kt` | Database tables: DailyTask, DailyGoal, MonthlyGoal |
| `app/src/main/java/com/personal/dailypath/data/prefs/SettingsRepository.kt` | Saved settings: app name, theme, Guru details and photo path |
| `app/src/main/java/com/personal/dailypath/data/storage/ImageStorage.kt` | Copies the chosen gallery photo into private app storage |
| `app/src/main/java/com/personal/dailypath/domain/DateFormats.kt` | Date text used on screens |
| `app/src/main/java/com/personal/dailypath/domain/StreakCalculator.kt` | Streak rules (current streak, longest streak, last seven days) |
| `app/src/main/java/com/personal/dailypath/domain/TodayTracker.kt` | Keeps "today" correct while the app is open |
| `app/src/main/java/com/personal/dailypath/ui/AppViewModelFactory.kt` | Creates the view models |
| `app/src/main/java/com/personal/dailypath/ui/MainViewModel.kt` | App-wide settings state |
| `app/src/main/java/com/personal/dailypath/ui/components/Basics.kt` | Headers, progress bar, check mark, toggle, empty state, day/month stepper |
| `app/src/main/java/com/personal/dailypath/ui/components/Dialogs.kt` | Add/edit and confirm dialogs |
| `app/src/main/java/com/personal/dailypath/ui/components/GuruImage.kt` | Loads and shows the saved photo |
| `app/src/main/java/com/personal/dailypath/ui/components/Mala.kt` | The seven-day bead strip and the small status bead |
| `app/src/main/java/com/personal/dailypath/ui/components/Rows.kt` | Task row and the edit/delete menu |
| `app/src/main/java/com/personal/dailypath/ui/dashboard/DashboardScreen.kt` | Today: main goal, streak, progress, tasks, month summary |
| `app/src/main/java/com/personal/dailypath/ui/dashboard/DashboardViewModel.kt` | Dashboard state and actions |
| `app/src/main/java/com/personal/dailypath/ui/history/HistoryScreen.kt` | Previous days and months |
| `app/src/main/java/com/personal/dailypath/ui/history/HistoryViewModel.kt` | Builds the history lists and totals |
| `app/src/main/java/com/personal/dailypath/ui/monthly/MonthlyScreen.kt` | Monthly goals (add, edit, complete, delete) |
| `app/src/main/java/com/personal/dailypath/ui/monthly/MonthlyViewModel.kt` | Monthly goals state and actions |
| `app/src/main/java/com/personal/dailypath/ui/navigation/AppNavigation.kt` | Bottom navigation and the screen routes |
| `app/src/main/java/com/personal/dailypath/ui/settings/SettingsScreen.kt` | App name, theme, Guru section switch, about |
| `app/src/main/java/com/personal/dailypath/ui/settings/SettingsViewModel.kt` | Settings actions |
| `app/src/main/java/com/personal/dailypath/ui/spiritual/SpiritualScreen.kt` | Optional Guru section with gallery photo picker |
| `app/src/main/java/com/personal/dailypath/ui/spiritual/SpiritualViewModel.kt` | Photo saving and details |
| `app/src/main/java/com/personal/dailypath/ui/tasks/TasksScreen.kt` | Tasks for any day (add, edit, complete, delete) |
| `app/src/main/java/com/personal/dailypath/ui/tasks/TasksViewModel.kt` | Tasks state and actions |
| `app/src/main/java/com/personal/dailypath/ui/theme/Color.kt` | Colour palette |
| `app/src/main/java/com/personal/dailypath/ui/theme/Theme.kt` | Light and dark themes |
| `app/src/main/java/com/personal/dailypath/ui/theme/Type.kt` | Typography |
| `app/src/main/java/com/personal/dailypath/ui/welcome/WelcomeScreen.kt` | First-launch screen where you name the app |

### Tests

| Path | Purpose |
| --- | --- |
| `app/src/test/java/com/personal/dailypath/domain/StreakCalculatorTest.kt` | Unit tests for the streak rules |

## Versions used

Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21, Compose BOM 2024.12.01 (Material 3),
Room 2.6.1, DataStore 1.1.1, Navigation Compose 2.8.5. Minimum Android version is 8.0 (API 26). Target is Android 15 (API 35).
All versions are listed in `gradle/libs.versions.toml`.
