# Release minification is disabled in this project, so no custom rules are required.
# Add keep rules here if you enable isMinifyEnabled in app/build.gradle.kts.
