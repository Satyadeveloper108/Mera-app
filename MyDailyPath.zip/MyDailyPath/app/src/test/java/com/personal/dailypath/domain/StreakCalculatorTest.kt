package com.personal.dailypath.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class StreakCalculatorTest {

    private val today = LocalDate.of(2026, 9, 20)

    /** The date [daysAgo] days before today. */
    private fun day(daysAgo: Int): LocalDate = today.minusDays(daysAgo.toLong())

    @Test
    fun noCompletedDays_streakIsZero() {
        val info = StreakCalculator.calculate(emptySet(), today)
        assertEquals(0, info.current)
        assertEquals(0, info.best)
        assertFalse(info.completedToday)
    }

    @Test
    fun completingToday_startsStreakAtOne() {
        val info = StreakCalculator.calculate(setOf(day(0)), today)
        assertEquals(1, info.current)
        assertTrue(info.completedToday)
    }

    @Test
    fun consecutiveDays_continueTheStreak() {
        val info = StreakCalculator.calculate(setOf(day(0), day(1), day(2), day(3)), today)
        assertEquals(4, info.current)
        assertEquals(4, info.best)
    }

    @Test
    fun missedDay_breaksTheStreak_andTheNextCompletionRestartsAtOne() {
        // Completed 3 and 2 days ago, missed yesterday, completed today.
        val info = StreakCalculator.calculate(setOf(day(3), day(2), day(0)), today)
        assertEquals(1, info.current)
        assertEquals(2, info.best)
    }

    @Test
    fun yesterdayCompleted_keepsStreakAliveWhileTodayIsOpen() {
        val info = StreakCalculator.calculate(setOf(day(1), day(2)), today)
        assertEquals(2, info.current)
        assertFalse(info.completedToday)
    }

    @Test
    fun twoDaysWithoutCompletion_resetsCurrentStreakToZero() {
        val info = StreakCalculator.calculate(setOf(day(2), day(3), day(4)), today)
        assertEquals(0, info.current)
        assertEquals(3, info.best)
    }

    @Test
    fun countingTheSameDayAgain_doesNotIncreaseTheStreak() {
        val once = StreakCalculator.calculate(setOf(day(1), day(0)), today)
        // Completing a day again just re-adds the same date to the set.
        val again = StreakCalculator.calculate(setOf(day(1), day(0), day(0)), today)
        assertEquals(2, once.current)
        assertEquals(once, again)
    }

    @Test
    fun recentDays_marksCompletedDaysAndToday() {
        val marks = StreakCalculator.recentDays(setOf(day(0), day(2)), today, count = 7)
        assertEquals(7, marks.size)
        assertEquals(day(6), marks.first().date)
        assertEquals(today, marks.last().date)
        assertTrue(marks.last().isToday)
        assertTrue(marks.last().completed)
        assertTrue(marks[4].completed) // two days ago
        assertFalse(marks[5].completed) // yesterday
    }
}
