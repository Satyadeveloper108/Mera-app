package com.personal.dailypath.ui.spiritual

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SpiritualUiState(
    val isLoading: Boolean = true,
    val photoPath: String? = null,
    val name: String = "",
    val note: String = "",
    val isSaving: Boolean = false,
    val errorMessage: String? = null,
)

class SpiritualViewModel(container: AppContainer) : ViewModel() {

    private val settingsRepository = container.settingsRepository
    private val imageStorage = container.imageStorage

    private val isSaving = MutableStateFlow(false)
    private val errorMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SpiritualUiState> = combine(
        settingsRepository.settings,
        isSaving,
        errorMessage,
    ) { settings, saving, error ->
        SpiritualUiState(
            isLoading = false,
            photoPath = settings.guruPhotoPath,
            name = settings.guruName,
            note = settings.guruNote,
            isSaving = saving,
            errorMessage = error,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SpiritualUiState())

    /** Called with the picture the person chose from the gallery. It is copied into the app's private storage. */
    fun onPhotoPicked(uri: Uri) {
        viewModelScope.launch {
            isSaving.value = true
            val newPath = imageStorage.savePhoto(uri)
            if (newPath == null) {
                errorMessage.value = "That picture could not be opened. Choose a different photo."
            } else {
                val oldPath = settingsRepository.settings.first().guruPhotoPath
                settingsRepository.setGuruPhotoPath(newPath)
                imageStorage.deletePhoto(oldPath)
            }
            isSaving.value = false
        }
    }

    fun removePhoto() {
        viewModelScope.launch {
            val oldPath = settingsRepository.settings.first().guruPhotoPath
            settingsRepository.setGuruPhotoPath(null)
            imageStorage.deletePhoto(oldPath)
        }
    }

    fun saveDetails(name: String, note: String) {
        viewModelScope.launch { settingsRepository.setGuruDetails(name, note) }
    }

    fun dismissError() {
        errorMessage.value = null
    }
}
