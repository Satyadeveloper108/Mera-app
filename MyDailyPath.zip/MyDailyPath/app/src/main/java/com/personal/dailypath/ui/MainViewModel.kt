package com.personal.dailypath.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.prefs.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** App-wide state: the saved settings decide the theme, the app name and whether to show the welcome screen. */
class MainViewModel(private val container: AppContainer) : ViewModel() {

    /** Null until the saved settings have been read from the phone. */
    val settings: StateFlow<AppSettings?> = container.settingsRepository.settings
        .stateIn<AppSettings?>(viewModelScope, SharingStarted.Eagerly, null)

    fun completeOnboarding(appName: String) {
        viewModelScope.launch { container.settingsRepository.completeOnboarding(appName) }
    }
}
