package com.personal.dailypath.domain

import java.time.LocalDate

/** Result of a streak calculation. */
data class StreakInfo(
    /**
     * Consecutive days with a completed main goal, ending today. While today's goal
     * is still open, the run that ended yesterday still counts, because the day is not over yet.
     */
    val current: Int,
    /** The longest run of consecutive completed days ever recorded. */
    val best: Int,
    /** True when today's main goal is already completed. */
    val completedToday: Boolean,
)

/** One day in the "last seven days" strip. */
data class DayMark(
    val date: LocalDate,
    val completed: Boolean,
    val isToday: Boolean,
)

/**
 * Streak rules, in one place:
 *
 *  - The streak is worked out from the set of days whose main goal is completed.
 *    A day is either in that set or not, so completing the same day twice can never add twice.
 *  - Completing today after completing yesterday continues the streak.
 *  - If a day is missed, the streak is broken. The next completion starts again at 1.
 */
object StreakCalculator {

    fun calculate(completedDates: Set<LocalDate>, today: LocalDate): StreakInfo {
        val completedToday = today in completedDates
        val yesterday = today.minusDays(1)

        // A run is "alive" if it includes today, or if it ended yesterday and today is still open.
        var cursor: LocalDate? = when {
            completedToday -> today
            yesterday in completedDates -> yesterday
            else -> null
        }
        var current = 0
        while (cursor != null && cursor in completedDates) {
            current++
            cursor = cursor.minusDays(1)
        }

        var best = 0
        var run = 0
        var previous: LocalDate? = null
        for (date in completedDates.sorted()) {
            run = if (previous != null && previous.plusDays(1) == date) run + 1 else 1
            if (run > best) best = run
            previous = date
        }

        return StreakInfo(current = current, best = best, completedToday = completedToday)
    }

    /** The last [count] days ending today, oldest first. */
    fun recentDays(completedDates: Set<LocalDate>, today: LocalDate, count: Int = 7): List<DayMark> =
        (count - 1 downTo 0).map { offset ->
            val date = today.minusDays(offset.toLong())
            DayMark(date = date, completed = date in completedDates, isToday = date == today)
        }
}
