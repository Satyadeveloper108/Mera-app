package com.personal.dailypath.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.YearMonth

@Dao
interface DailyTaskDao {

    @Query("SELECT * FROM daily_tasks WHERE date = :date ORDER BY createdAt ASC, id ASC")
    fun observeForDate(date: LocalDate): Flow<List<DailyTask>>

    @Query("SELECT * FROM daily_tasks ORDER BY date DESC, createdAt ASC, id ASC")
    fun observeAll(): Flow<List<DailyTask>>

    @Insert
    suspend fun insert(task: DailyTask): Long

    @Query("UPDATE daily_tasks SET title = :title WHERE id = :id")
    suspend fun updateTitle(id: Long, title: String)

    @Query("UPDATE daily_tasks SET isCompleted = :completed, completedAt = :completedAt WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean, completedAt: Long?)

    @Query("DELETE FROM daily_tasks WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface DailyGoalDao {

    @Query("SELECT * FROM daily_goals ORDER BY date DESC")
    fun observeAll(): Flow<List<DailyGoal>>

    /** Creates the goal for a day unless one already exists. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIfAbsent(goal: DailyGoal): Long

    @Query("UPDATE daily_goals SET title = :title WHERE date = :date")
    suspend fun updateTitle(date: LocalDate, title: String)

    /**
     * Only changes the row when the state really differs, so completing the same
     * day twice is a no-op. Returns the number of rows changed (0 or 1).
     */
    @Query(
        "UPDATE daily_goals SET isCompleted = :completed, completedAt = :completedAt " +
            "WHERE date = :date AND isCompleted != :completed"
    )
    suspend fun setCompleted(date: LocalDate, completed: Boolean, completedAt: Long?): Int

    /** Completed goals are kept for the streak history, so only open goals can be removed. */
    @Query("DELETE FROM daily_goals WHERE date = :date AND isCompleted = 0")
    suspend fun deleteIfNotCompleted(date: LocalDate)
}

@Dao
interface MonthlyGoalDao {

    @Query("SELECT * FROM monthly_goals WHERE month = :month ORDER BY createdAt ASC, id ASC")
    fun observeForMonth(month: YearMonth): Flow<List<MonthlyGoal>>

    @Query("SELECT * FROM monthly_goals ORDER BY month DESC, createdAt ASC, id ASC")
    fun observeAll(): Flow<List<MonthlyGoal>>

    @Insert
    suspend fun insert(goal: MonthlyGoal): Long

    @Query("UPDATE monthly_goals SET title = :title, notes = :notes WHERE id = :id")
    suspend fun updateDetails(id: Long, title: String, notes: String)

    @Query("UPDATE monthly_goals SET isCompleted = :completed, completedAt = :completedAt WHERE id = :id")
    suspend fun setCompleted(id: Long, completed: Boolean, completedAt: Long?)

    @Query("DELETE FROM monthly_goals WHERE id = :id")
    suspend fun deleteById(id: Long)
}
