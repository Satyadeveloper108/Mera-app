package com.personal.dailypath.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

/**
 * The on-device SQLite database. Everything the app remembers about tasks,
 * goals, streaks and history lives here, so it survives closing the app.
 */
@Database(
    entities = [DailyTask::class, DailyGoal::class, MonthlyGoal::class],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dailyTaskDao(): DailyTaskDao

    abstract fun dailyGoalDao(): DailyGoalDao

    abstract fun monthlyGoalDao(): MonthlyGoalDao

    companion object {
        private const val DATABASE_NAME = "daily_path.db"

        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DATABASE_NAME,
            ).build()
    }
}
