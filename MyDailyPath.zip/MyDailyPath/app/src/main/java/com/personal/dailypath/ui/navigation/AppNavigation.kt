package com.personal.dailypath.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.personal.dailypath.data.prefs.AppSettings
import com.personal.dailypath.ui.dashboard.DashboardScreen
import com.personal.dailypath.ui.history.HistoryScreen
import com.personal.dailypath.ui.monthly.MonthlyScreen
import com.personal.dailypath.ui.settings.SettingsScreen
import com.personal.dailypath.ui.spiritual.SpiritualScreen
import com.personal.dailypath.ui.tasks.TasksScreen

/** The screens reachable from the bottom bar. */
sealed class Destination(
    val route: String,
    val label: String,
    val icon: ImageVector,
) {
    data object Today : Destination("today", "Today", Icons.Filled.Home)
    data object Tasks : Destination("tasks", "Tasks", Icons.Filled.CheckCircle)
    data object Monthly : Destination("monthly", "Monthly", Icons.Filled.Star)
    data object History : Destination("history", "History", Icons.Filled.DateRange)
    data object Guru : Destination("spiritual", "Guru", Icons.Filled.Favorite)
}

private const val ROUTE_SETTINGS = "settings"

@Composable
fun AppRoot(settings: AppSettings) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val tabs: List<Destination> = remember(settings.spiritualEnabled) {
        buildList<Destination> {
            add(Destination.Today)
            add(Destination.Tasks)
            add(Destination.Monthly)
            add(Destination.History)
            if (settings.spiritualEnabled) add(Destination.Guru)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (tabs.any { it.route == currentRoute }) {
                AppBottomBar(
                    tabs = tabs,
                    currentRoute = currentRoute,
                    onSelect = { destination -> navController.navigateToTab(destination) },
                )
            }
        },
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Today.route,
            modifier = Modifier.padding(innerPadding),
        ) {
            composable(Destination.Today.route) {
                DashboardScreen(
                    onOpenMonthly = { navController.navigateToTab(Destination.Monthly) },
                    onOpenSettings = { navController.navigate(ROUTE_SETTINGS) },
                    onOpenSpiritual = { navController.navigateToTab(Destination.Guru) },
                )
            }
            composable(Destination.Tasks.route) { TasksScreen() }
            composable(Destination.Monthly.route) { MonthlyScreen() }
            composable(Destination.History.route) { HistoryScreen() }
            composable(Destination.Guru.route) { SpiritualScreen() }
            composable(ROUTE_SETTINGS) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

@Composable
private fun AppBottomBar(
    tabs: List<Destination>,
    currentRoute: String?,
    onSelect: (Destination) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    NavigationBar(containerColor = scheme.surfaceContainerLow) {
        tabs.forEach { destination ->
            NavigationBarItem(
                selected = currentRoute == destination.route,
                onClick = { onSelect(destination) },
                icon = { Icon(imageVector = destination.icon, contentDescription = null) },
                label = { Text(destination.label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = scheme.onPrimaryContainer,
                    selectedTextColor = scheme.onSurface,
                    indicatorColor = scheme.primaryContainer,
                    unselectedIconColor = scheme.onSurfaceVariant,
                    unselectedTextColor = scheme.onSurfaceVariant,
                ),
            )
        }
    }
}

private fun NavHostController.navigateToTab(destination: Destination) {
    navigate(destination.route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
