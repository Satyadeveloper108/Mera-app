package com.personal.dailypath.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.personal.dailypath.AppContainer
import com.personal.dailypath.LifeApp
import com.personal.dailypath.ui.dashboard.DashboardViewModel
import com.personal.dailypath.ui.history.HistoryViewModel
import com.personal.dailypath.ui.monthly.MonthlyViewModel
import com.personal.dailypath.ui.settings.SettingsViewModel
import com.personal.dailypath.ui.spiritual.SpiritualViewModel
import com.personal.dailypath.ui.tasks.TasksViewModel

/** Builds the view models with the app's shared objects, without needing a dependency-injection library. */
class AppViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        val viewModel: ViewModel = when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> MainViewModel(container)
            modelClass.isAssignableFrom(DashboardViewModel::class.java) -> DashboardViewModel(container)
            modelClass.isAssignableFrom(TasksViewModel::class.java) -> TasksViewModel(container)
            modelClass.isAssignableFrom(MonthlyViewModel::class.java) -> MonthlyViewModel(container)
            modelClass.isAssignableFrom(HistoryViewModel::class.java) -> HistoryViewModel(container)
            modelClass.isAssignableFrom(SpiritualViewModel::class.java) -> SpiritualViewModel(container)
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(container)
            else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
        return viewModel as T
    }
}

@Composable
fun rememberAppViewModelFactory(): ViewModelProvider.Factory {
    val app = LocalContext.current.applicationContext as LifeApp
    return remember(app) { AppViewModelFactory(app.container) }
}
