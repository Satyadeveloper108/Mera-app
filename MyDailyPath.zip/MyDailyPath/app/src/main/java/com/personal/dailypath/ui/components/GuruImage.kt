package com.personal.dailypath.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.personal.dailypath.data.storage.ImageStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Shows the saved photo from private storage. Shows a plain tinted block while loading or if the file is missing. */
@Composable
fun GuruImage(
    path: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    maxSidePx: Int = 1600,
) {
    val bitmap: ImageBitmap? by produceState<ImageBitmap?>(null, path, maxSidePx) {
        value = if (path == null) {
            null
        } else {
            withContext(Dispatchers.IO) {
                ImageStorage.decodeForDisplay(path, maxSidePx)?.asImageBitmap()
            }
        }
    }
    val image = bitmap
    if (image != null) {
        Image(
            bitmap = image,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale,
        )
    } else {
        Box(modifier = modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh))
    }
}
