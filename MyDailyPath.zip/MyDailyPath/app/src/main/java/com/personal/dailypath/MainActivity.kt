package com.personal.dailypath

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.data.prefs.ThemeMode
import com.personal.dailypath.ui.AppViewModelFactory
import com.personal.dailypath.ui.MainViewModel
import com.personal.dailypath.ui.navigation.AppRoot
import com.personal.dailypath.ui.theme.DailyPathTheme
import com.personal.dailypath.ui.welcome.WelcomeScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val LIGHT_SCRIM = AndroidColor.argb(0xE6, 0xFF, 0xFF, 0xFF)
private val DARK_SCRIM = AndroidColor.argb(0x80, 0x1B, 0x1B, 0x1B)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as LifeApp).container
        val viewModelFactory = AppViewModelFactory(container)

        // While the app is on screen, keep "today" accurate, so the dashboard rolls over at midnight.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    container.todayTracker.refresh()
                    delay(30_000L)
                }
            }
        }

        setContent {
            val mainViewModel: MainViewModel = viewModel(factory = viewModelFactory)
            val settings by mainViewModel.settings.collectAsStateWithLifecycle()
            val current = settings

            val darkTheme = when (current?.themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                else -> isSystemInDarkTheme()
            }

            // Keep the status and navigation bar icons readable when the theme is chosen inside the app.
            DisposableEffect(darkTheme) {
                this@MainActivity.enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(
                        AndroidColor.TRANSPARENT,
                        AndroidColor.TRANSPARENT,
                    ) { darkTheme },
                    navigationBarStyle = SystemBarStyle.auto(
                        LIGHT_SCRIM,
                        DARK_SCRIM,
                    ) { darkTheme },
                )
                onDispose { }
            }

            DailyPathTheme(darkTheme = darkTheme) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
                ) {
                    when {
                        // Settings are still being read from the phone.
                        current == null -> Unit
                        !current.onboardingDone -> WelcomeScreen(onStart = { name -> mainViewModel.completeOnboarding(name) })
                        else -> AppRoot(settings = current)
                    }
                }
            }
        }
    }
}
