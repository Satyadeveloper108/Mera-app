package com.personal.dailypath.ui.tasks

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.data.local.DailyTask
import com.personal.dailypath.domain.DateFormats
import com.personal.dailypath.ui.components.ConfirmDialog
import com.personal.dailypath.ui.components.EmptyState
import com.personal.dailypath.ui.components.PeriodNavigator
import com.personal.dailypath.ui.components.ProgressBar
import com.personal.dailypath.ui.components.ScreenHeader
import com.personal.dailypath.ui.components.SectionHeader
import com.personal.dailypath.ui.components.TaskRow
import com.personal.dailypath.ui.components.TextInputDialog
import com.personal.dailypath.ui.rememberAppViewModelFactory

/** Add, edit, complete and delete tasks for any day. Use the arrows to plan ahead or look back. */
@Composable
fun TasksScreen(
    modifier: Modifier = Modifier,
    viewModel: TasksViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showAddDialog by rememberSaveable { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<DailyTask?>(null) }
    var taskToDelete by remember { mutableStateOf<DailyTask?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        if (!state.isLoading) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                item(key = "header") {
                    ScreenHeader(
                        title = "Tasks",
                        subtitle = "Plan and check off what you need to do each day.",
                    )
                }

                item(key = "navigator") {
                    Column {
                        PeriodNavigator(
                            title = DateFormats.relativeDay(state.date, state.today),
                            subtitle = DateFormats.fullDate(state.date),
                            previousDescription = "Previous day",
                            nextDescription = "Next day",
                            onPrevious = { viewModel.showPreviousDay() },
                            onNext = { viewModel.showNextDay() },
                        )
                        if (state.date != state.today) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                            ) {
                                TextButton(onClick = { viewModel.showToday() }) {
                                    Text("Back to today")
                                }
                            }
                        }
                    }
                }

                item(key = "progress") {
                    Column(modifier = Modifier.padding(top = 20.dp)) {
                        SectionHeader(
                            title = "Progress",
                            trailing = if (state.total == 0) null else "${state.completed.size} of ${state.total} done",
                        )
                        if (state.total > 0) {
                            Spacer(Modifier.height(12.dp))
                            ProgressBar(
                                progress = state.progress,
                                modifier = Modifier.padding(horizontal = 20.dp),
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                if (state.total == 0) {
                    item(key = "empty") {
                        EmptyState(
                            title = "No tasks for this day",
                            message = "Tap Add task to plan this day.",
                        )
                    }
                }

                items(state.pending, key = { it.id }) { task ->
                    TaskRow(
                        task = task,
                        onToggle = { viewModel.toggleTask(task) },
                        onEdit = { taskToEdit = task },
                        onDelete = { taskToDelete = task },
                        modifier = Modifier.animateItem(),
                    )
                }

                if (state.completed.isNotEmpty()) {
                    item(key = "completed-header") {
                        Text(
                            text = "Completed",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp),
                        )
                    }
                    items(state.completed, key = { it.id }) { task ->
                        TaskRow(
                            task = task,
                            onToggle = { viewModel.toggleTask(task) },
                            onEdit = { taskToEdit = task },
                            onDelete = { taskToDelete = task },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Add task") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
        )
    }

    if (showAddDialog) {
        TextInputDialog(
            title = "New task",
            label = "Task",
            initialValue = "",
            confirmLabel = "Add",
            supportingText = if (state.date == state.today) {
                null
            } else {
                "This task will be added to ${DateFormats.fullDate(state.date)}."
            },
            onConfirm = { text ->
                viewModel.addTask(text)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false },
        )
    }

    taskToEdit?.let { task ->
        TextInputDialog(
            title = "Edit task",
            label = "Task",
            initialValue = task.title,
            confirmLabel = "Save",
            onConfirm = { text ->
                viewModel.renameTask(task, text)
                taskToEdit = null
            },
            onDismiss = { taskToEdit = null },
        )
    }

    taskToDelete?.let { task ->
        ConfirmDialog(
            title = "Delete task?",
            message = "\"${task.title}\" will be deleted.",
            confirmLabel = "Delete",
            onConfirm = {
                viewModel.deleteTask(task)
                taskToDelete = null
            },
            onDismiss = { taskToDelete = null },
        )
    }
}
