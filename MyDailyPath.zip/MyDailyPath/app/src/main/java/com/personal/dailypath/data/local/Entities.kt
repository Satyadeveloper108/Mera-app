package com.personal.dailypath.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate
import java.time.YearMonth

/** A to-do item that belongs to one calendar day. */
@Entity(tableName = "daily_tasks", indices = [Index(value = ["date"])])
data class DailyTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val date: LocalDate,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

/**
 * The single main goal for one calendar day.
 *
 * The date is the primary key, so a day can never have more than one main goal,
 * and a day can never be counted twice in the streak.
 */
@Entity(tableName = "daily_goals")
data class DailyGoal(
    @PrimaryKey val date: LocalDate,
    val title: String,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

/** A personal goal for one calendar month. */
@Entity(tableName = "monthly_goals", indices = [Index(value = ["month"])])
data class MonthlyGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val notes: String = "",
    val month: YearMonth,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
)
