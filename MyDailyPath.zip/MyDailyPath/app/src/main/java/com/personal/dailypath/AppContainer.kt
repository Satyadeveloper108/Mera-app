package com.personal.dailypath

import android.content.Context
import com.personal.dailypath.data.LifeRepository
import com.personal.dailypath.data.local.AppDatabase
import com.personal.dailypath.data.prefs.SettingsRepository
import com.personal.dailypath.data.storage.ImageStorage
import com.personal.dailypath.domain.TodayTracker

/** Creates and holds the app's long-lived objects (database, settings, photo storage). */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    private val database: AppDatabase by lazy { AppDatabase.create(appContext) }

    val todayTracker = TodayTracker()

    val settingsRepository: SettingsRepository by lazy { SettingsRepository(appContext) }

    val imageStorage: ImageStorage by lazy { ImageStorage(appContext) }

    val repository: LifeRepository by lazy {
        LifeRepository(
            taskDao = database.dailyTaskDao(),
            goalDao = database.dailyGoalDao(),
            monthlyGoalDao = database.monthlyGoalDao(),
        )
    }
}
