package com.personal.dailypath.ui.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.local.DailyTask
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class TasksUiState(
    val isLoading: Boolean = true,
    val date: LocalDate = LocalDate.now(),
    val today: LocalDate = LocalDate.now(),
    val pending: List<DailyTask> = emptyList(),
    val completed: List<DailyTask> = emptyList(),
) {
    val total: Int get() = pending.size + completed.size

    val progress: Float get() = if (total == 0) 0f else completed.size.toFloat() / total
}

@OptIn(ExperimentalCoroutinesApi::class)
class TasksViewModel(container: AppContainer) : ViewModel() {

    private val repository = container.repository
    private val tracker = container.todayTracker

    /** The day the person chose to look at. Null means "follow today". */
    private val selectedDate = MutableStateFlow<LocalDate?>(null)

    val uiState: StateFlow<TasksUiState> = combine(selectedDate, tracker.today) { selected, today ->
        (selected ?: today) to today
    }
        .flatMapLatest { (date, today) ->
            repository.observeTasks(date).map { tasks ->
                TasksUiState(
                    isLoading = false,
                    date = date,
                    today = today,
                    pending = tasks.filter { !it.isCompleted },
                    completed = tasks.filter { it.isCompleted },
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TasksUiState())

    private fun currentDate(): LocalDate = selectedDate.value ?: tracker.today.value

    fun showPreviousDay() {
        val previous = currentDate().minusDays(1)
        selectedDate.value = if (previous == tracker.today.value) null else previous
    }

    fun showNextDay() {
        val next = currentDate().plusDays(1)
        selectedDate.value = if (next == tracker.today.value) null else next
    }

    fun showToday() {
        selectedDate.value = null
    }

    fun addTask(title: String) {
        val date = currentDate()
        viewModelScope.launch { repository.addTask(title, date) }
    }

    fun toggleTask(task: DailyTask) {
        viewModelScope.launch { repository.setTaskCompleted(task.id, !task.isCompleted) }
    }

    fun renameTask(task: DailyTask, title: String) {
        viewModelScope.launch { repository.renameTask(task.id, title) }
    }

    fun deleteTask(task: DailyTask) {
        viewModelScope.launch { repository.deleteTask(task.id) }
    }
}
