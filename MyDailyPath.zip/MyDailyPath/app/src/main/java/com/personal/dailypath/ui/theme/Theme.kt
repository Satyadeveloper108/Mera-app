package com.personal.dailypath.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Tulsi,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = TulsiMist,
    onPrimaryContainer = TulsiInk,
    secondary = Color(0xFF7A5A00),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = MarigoldSoft,
    onSecondaryContainer = MarigoldInk,
    tertiary = Marigold,
    onTertiary = MarigoldInk,
    background = Ash,
    onBackground = Ink,
    surface = Ash,
    onSurface = Ink,
    surfaceVariant = Color(0xFFE0E7DF),
    onSurfaceVariant = InkMuted,
    surfaceTint = Tulsi,
    inverseSurface = Color(0xFF2D3A34),
    inverseOnSurface = Color(0xFFEAF1EC),
    inversePrimary = NightTulsi,
    error = Brick,
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFBDAD5),
    onErrorContainer = Color(0xFF410E0B),
    outline = Color(0xFF86948D),
    outlineVariant = Color(0xFFC9D3CC),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF7F9F5),
    surfaceContainer = Color(0xFFEDF1EA),
    surfaceContainerHigh = Color(0xFFE7ECE4),
    surfaceContainerHighest = Color(0xFFE0E6DD),
)

private val DarkColors = darkColorScheme(
    primary = NightTulsi,
    onPrimary = Color(0xFF06382A),
    primaryContainer = NightTulsiContainer,
    onPrimaryContainer = TulsiMist,
    secondary = Color(0xFFE6C36A),
    onSecondary = Color(0xFF3B2800),
    secondaryContainer = Color(0xFF4A3800),
    onSecondaryContainer = MarigoldSoft,
    tertiary = NightMarigold,
    onTertiary = Color(0xFF3B2800),
    background = NightGreen,
    onBackground = NightInk,
    surface = NightGreen,
    onSurface = NightInk,
    surfaceVariant = Color(0xFF2A3A33),
    onSurfaceVariant = NightInkMuted,
    surfaceTint = NightTulsi,
    inverseSurface = NightInk,
    inverseOnSurface = Color(0xFF2D3A34),
    inversePrimary = Tulsi,
    error = Color(0xFFFFB4A9),
    onError = Color(0xFF4A0E08),
    errorContainer = Color(0xFF5C1B14),
    onErrorContainer = Color(0xFFFBDAD5),
    outline = Color(0xFF71817A),
    outlineVariant = Color(0xFF34443D),
    surfaceContainerLowest = Color(0xFF0A120F),
    surfaceContainerLow = Color(0xFF131D19),
    surfaceContainer = Color(0xFF17221E),
    surfaceContainerHigh = Color(0xFF1E2B26),
    surfaceContainerHighest = Color(0xFF263530),
)

/** Colours specific to this app: the main-goal panel and the streak beads. */
@Immutable
data class DailyColors(
    val hero: Color,
    val onHero: Color,
    val onHeroMuted: Color,
    val bead: Color,
    val onBead: Color,
    val beadOutline: Color,
)

private val LightDailyColors = DailyColors(
    hero = Tulsi,
    onHero = Color(0xFFFFFFFF),
    onHeroMuted = Color(0xFFCFE3D9),
    bead = Marigold,
    onBead = MarigoldInk,
    beadOutline = Color(0x99FFFFFF),
)

private val DarkDailyColors = DailyColors(
    hero = NightTulsiContainer,
    onHero = Color(0xFFF1F7F3),
    onHeroMuted = Color(0xFFB9D3C7),
    bead = NightMarigold,
    onBead = Color(0xFF3B2800),
    beadOutline = Color(0x99F1F7F3),
)

private val LocalDailyColors = staticCompositionLocalOf { LightDailyColors }

object AppTheme {
    val colors: DailyColors
        @Composable
        @ReadOnlyComposable
        get() = LocalDailyColors.current
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun DailyPathTheme(
    darkTheme: Boolean,
    content: @Composable () -> Unit,
) {
    CompositionLocalProvider(
        LocalDailyColors provides if (darkTheme) DarkDailyColors else LightDailyColors,
    ) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkColors else LightColors,
            typography = AppTypography,
            shapes = AppShapes,
            content = content,
        )
    }
}
