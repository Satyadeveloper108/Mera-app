package com.personal.dailypath.ui.spiritual

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.ui.components.ConfirmDialog
import com.personal.dailypath.ui.components.GuruImage
import com.personal.dailypath.ui.components.ScreenHeader
import com.personal.dailypath.ui.components.TwoFieldDialog
import com.personal.dailypath.ui.rememberAppViewModelFactory

/** Like the arch of a temple niche: round at the top, gently rounded at the bottom. */
private val ArchShape = RoundedCornerShape(
    topStart = CornerSize(50),
    topEnd = CornerSize(50),
    bottomEnd = CornerSize(24.dp),
    bottomStart = CornerSize(24.dp),
)

/** An optional personal section: a photo of your Guru from the phone's gallery, plus a name and a line to remember. */
@Composable
fun SpiritualScreen(
    modifier: Modifier = Modifier,
    viewModel: SpiritualViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showDetailsDialog by rememberSaveable { mutableStateOf(false) }
    var showRemoveDialog by rememberSaveable { mutableStateOf(false) }
    var showFullPhoto by rememberSaveable { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) viewModel.onPhotoPicked(uri)
    }
    val choosePhoto = {
        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val hasPhoto = state.photoPath != null
    val hasDetails = state.name.isNotBlank() || state.note.isNotBlank()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp),
    ) {
        ScreenHeader(
            title = "Spiritual",
            subtitle = "Keep your Guru's photo close, with a line to remember.",
        )
        Spacer(Modifier.height(16.dp))

        PhotoFrame(
            photoPath = state.photoPath,
            name = state.name,
            isSaving = state.isSaving,
            onOpenFull = { showFullPhoto = true },
            onChoose = { choosePhoto() },
        )

        if (hasDetails) {
            Column(modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 20.dp)) {
                if (state.name.isNotBlank()) {
                    Text(text = state.name, style = MaterialTheme.typography.headlineSmall)
                }
                if (state.note.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = state.note,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                onClick = { choosePhoto() },
                enabled = !state.isSaving,
                modifier = Modifier.weight(1f),
            ) {
                Text(if (hasPhoto) "Change photo" else "Choose photo")
            }
            OutlinedButton(
                onClick = { showDetailsDialog = true },
                modifier = Modifier.weight(1f),
            ) {
                Text(if (hasDetails) "Edit details" else "Add name")
            }
        }
        if (hasPhoto) {
            TextButton(
                onClick = { showRemoveDialog = true },
                colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error),
                modifier = Modifier.padding(horizontal = 12.dp),
            ) {
                Text("Remove photo")
            }
        }
    }

    if (showFullPhoto && hasPhoto) {
        Dialog(
            onDismissRequest = { showFullPhoto = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { showFullPhoto = false },
                contentAlignment = Alignment.Center,
            ) {
                GuruImage(
                    path = state.photoPath,
                    contentDescription = if (state.name.isNotBlank()) "Photo of ${state.name}" else "Photo of your Guru",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }

    if (showDetailsDialog) {
        TwoFieldDialog(
            title = "Name and note",
            firstLabel = "Name",
            secondLabel = "A line to remember (optional)",
            firstInitial = state.name,
            secondInitial = state.note,
            confirmLabel = "Save",
            requireFirst = false,
            onConfirm = { name, note ->
                viewModel.saveDetails(name, note)
                showDetailsDialog = false
            },
            onDismiss = { showDetailsDialog = false },
        )
    }

    if (showRemoveDialog) {
        ConfirmDialog(
            title = "Remove photo?",
            message = "The photo will be removed from this app. The original in your gallery is not changed.",
            confirmLabel = "Remove",
            onConfirm = {
                viewModel.removePhoto()
                showRemoveDialog = false
            },
            onDismiss = { showRemoveDialog = false },
        )
    }

    state.errorMessage?.let { message ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissError() },
            title = { Text(text = "Photo not added", style = MaterialTheme.typography.headlineSmall) },
            text = { Text(text = message, style = MaterialTheme.typography.bodyMedium) },
            confirmButton = {
                TextButton(onClick = { viewModel.dismissError() }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun PhotoFrame(
    photoPath: String?,
    name: String,
    isSaving: Boolean,
    onOpenFull: () -> Unit,
    onChoose: () -> Unit,
) {
    val hasPhoto = photoPath != null
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .fillMaxWidth()
                .aspectRatio(3f / 4f)
                .clip(ArchShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .border(width = 2.dp, color = MaterialTheme.colorScheme.outlineVariant, shape = ArchShape)
                .clickable(
                    onClickLabel = if (hasPhoto) "View photo full screen" else "Choose a photo",
                    onClick = if (hasPhoto) onOpenFull else onChoose,
                ),
            contentAlignment = Alignment.Center,
        ) {
            if (hasPhoto) {
                GuruImage(
                    path = photoPath,
                    contentDescription = if (name.isNotBlank()) "Photo of $name" else "Photo of your Guru",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(32.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Add a photo of your Guru",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Tap here to choose a picture from your phone's gallery.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            if (isSaving) {
                CircularProgressIndicator()
            }
        }
    }
}
