package com.personal.dailypath.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.data.prefs.ThemeMode
import com.personal.dailypath.ui.components.SegmentedToggle
import com.personal.dailypath.ui.components.TextInputDialog
import com.personal.dailypath.ui.rememberAppViewModelFactory

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var showRenameDialog by rememberSaveable { mutableStateOf(false) }

    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 20.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(text = "Settings", style = MaterialTheme.typography.headlineMedium)
        }

        SettingsGroup(title = "App name") {
            Text(text = settings.appName, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = "This name appears at the top of your dashboard.",
                style = MaterialTheme.typography.bodyMedium,
                color = muted,
            )
            OutlinedButton(onClick = { showRenameDialog = true }) { Text("Rename app") }
            Text(
                text = "The name under the app icon on your home screen is set in the project's strings.xml (app_name).",
                style = MaterialTheme.typography.bodySmall,
                color = muted,
            )
        }

        SettingsDivider()

        SettingsGroup(title = "Appearance") {
            SegmentedToggle(
                options = listOf("System", "Light", "Dark"),
                selectedIndex = settings.themeMode.ordinal,
                onSelect = { index -> viewModel.setThemeMode(ThemeMode.entries[index]) },
            )
        }

        SettingsDivider()

        SettingsGroup(title = "Spiritual section") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "Show the Guru section", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        text = "Adds a tab for your Guru's photo. Turning it off keeps the photo.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                    )
                }
                Switch(
                    checked = settings.spiritualEnabled,
                    onCheckedChange = { enabled -> viewModel.setSpiritualEnabled(enabled) },
                )
            }
        }

        SettingsDivider()

        SettingsGroup(title = "Your data") {
            Text(
                text = "Everything you enter is stored only on this phone. The app needs no account and no internet connection.",
                style = MaterialTheme.typography.bodyMedium,
                color = muted,
            )
        }

        SettingsDivider()

        SettingsGroup(title = "How the streak works") {
            Text(
                text = "Complete your main goal each day to continue the streak. " +
                    "If you miss a day, the streak ends, and the next time you complete a goal it starts again at 1. " +
                    "Completing the same day's goal more than once never adds extra days.",
                style = MaterialTheme.typography.bodyMedium,
                color = muted,
            )
        }
    }

    if (showRenameDialog) {
        TextInputDialog(
            title = "Rename app",
            label = "App name",
            initialValue = settings.appName,
            confirmLabel = "Save",
            onConfirm = { name ->
                viewModel.setAppName(name)
                showRenameDialog = false
            },
            onDismiss = { showRenameDialog = false },
        )
    }
}

@Composable
private fun SettingsGroup(
    title: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text = title, style = MaterialTheme.typography.titleLarge)
        content()
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 20.dp),
        color = MaterialTheme.colorScheme.outlineVariant,
    )
}
