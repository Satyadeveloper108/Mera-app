package com.personal.dailypath.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.local.DailyGoal
import com.personal.dailypath.data.local.DailyTask
import com.personal.dailypath.domain.DateFormats
import com.personal.dailypath.domain.DayMark
import com.personal.dailypath.domain.StreakCalculator
import com.personal.dailypath.domain.StreakInfo
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

data class DashboardUiState(
    val isLoading: Boolean = true,
    val appName: String = "",
    val today: LocalDate = LocalDate.now(),
    val goal: DailyGoal? = null,
    val streak: StreakInfo = StreakInfo(current = 0, best = 0, completedToday = false),
    val recentDays: List<DayMark> = emptyList(),
    val pendingTasks: List<DailyTask> = emptyList(),
    val completedTasks: List<DailyTask> = emptyList(),
    val monthName: String = "",
    val monthGoalsDone: Int = 0,
    val monthGoalsTotal: Int = 0,
    val guruPhotoPath: String? = null,
    val showSpiritual: Boolean = false,
) {
    val totalTasks: Int get() = pendingTasks.size + completedTasks.size

    val taskProgress: Float
        get() = if (totalTasks == 0) 0f else completedTasks.size.toFloat() / totalTasks
}

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModel(private val container: AppContainer) : ViewModel() {

    private val repository = container.repository
    private val tracker = container.todayTracker

    val uiState: StateFlow<DashboardUiState> = tracker.today
        .flatMapLatest { day ->
            val month = YearMonth.from(day)
            combine(
                repository.observeTasks(day),
                repository.observeAllGoals(),
                repository.observeMonthlyGoals(month),
                container.settingsRepository.settings,
            ) { tasks, goals, monthGoals, settings ->
                val completedDates = goals.filter { it.isCompleted }.map { it.date }.toSet()
                DashboardUiState(
                    isLoading = false,
                    appName = settings.appName,
                    today = day,
                    goal = goals.firstOrNull { it.date == day },
                    streak = StreakCalculator.calculate(completedDates, day),
                    recentDays = StreakCalculator.recentDays(completedDates, day),
                    pendingTasks = tasks.filter { !it.isCompleted },
                    completedTasks = tasks.filter { it.isCompleted },
                    monthName = DateFormats.monthName(month),
                    monthGoalsDone = monthGoals.count { it.isCompleted },
                    monthGoalsTotal = monthGoals.size,
                    guruPhotoPath = settings.guruPhotoPath,
                    showSpiritual = settings.spiritualEnabled,
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardUiState())

    fun addTask(title: String) {
        viewModelScope.launch { repository.addTask(title, tracker.today.value) }
    }

    fun toggleTask(task: DailyTask) {
        viewModelScope.launch { repository.setTaskCompleted(task.id, !task.isCompleted) }
    }

    fun renameTask(task: DailyTask, title: String) {
        viewModelScope.launch { repository.renameTask(task.id, title) }
    }

    fun deleteTask(task: DailyTask) {
        viewModelScope.launch { repository.deleteTask(task.id) }
    }

    fun saveGoal(title: String) {
        viewModelScope.launch { repository.saveGoal(tracker.today.value, title) }
    }

    /** Completes today's goal, or reopens it. A day can only be completed once, however often this is called. */
    fun toggleGoalCompleted() {
        val goal = uiState.value.goal ?: return
        viewModelScope.launch {
            // If midnight has passed while the app was open, move on to the new day instead of crediting the old one.
            if (goal.date != LocalDate.now()) {
                tracker.refresh()
                return@launch
            }
            repository.setGoalCompleted(goal.date, !goal.isCompleted)
        }
    }

    fun removeGoal() {
        val goal = uiState.value.goal ?: return
        viewModelScope.launch { repository.removeGoal(goal.date) }
    }
}
