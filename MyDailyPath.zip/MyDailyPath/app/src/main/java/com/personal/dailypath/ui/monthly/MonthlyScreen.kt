package com.personal.dailypath.ui.monthly

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.data.local.MonthlyGoal
import com.personal.dailypath.domain.DateFormats
import com.personal.dailypath.ui.components.CheckMark
import com.personal.dailypath.ui.components.ConfirmDialog
import com.personal.dailypath.ui.components.EmptyState
import com.personal.dailypath.ui.components.ItemMenu
import com.personal.dailypath.ui.components.PeriodNavigator
import com.personal.dailypath.ui.components.ProgressBar
import com.personal.dailypath.ui.components.ScreenHeader
import com.personal.dailypath.ui.components.SectionHeader
import com.personal.dailypath.ui.components.TwoFieldDialog
import com.personal.dailypath.ui.rememberAppViewModelFactory

/** Personal goals for a month. Add, edit, complete and delete them, and step between months. */
@Composable
fun MonthlyScreen(
    modifier: Modifier = Modifier,
    viewModel: MonthlyViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showAddDialog by rememberSaveable { mutableStateOf(false) }
    var goalToEdit by remember { mutableStateOf<MonthlyGoal?>(null) }
    var goalToDelete by remember { mutableStateOf<MonthlyGoal?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        if (!state.isLoading) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 96.dp),
            ) {
                item(key = "header") {
                    ScreenHeader(
                        title = "Monthly goals",
                        subtitle = "What you want to accomplish this month.",
                    )
                }

                item(key = "navigator") {
                    Column {
                        PeriodNavigator(
                            title = DateFormats.monthYear(state.month),
                            subtitle = monthCaption(state),
                            previousDescription = "Previous month",
                            nextDescription = "Next month",
                            onPrevious = { viewModel.showPreviousMonth() },
                            onNext = { viewModel.showNextMonth() },
                        )
                        if (state.month != state.currentMonth) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                            ) {
                                TextButton(onClick = { viewModel.showCurrentMonth() }) {
                                    Text("Back to this month")
                                }
                            }
                        }
                    }
                }

                item(key = "progress") {
                    Column(modifier = Modifier.padding(top = 20.dp)) {
                        SectionHeader(
                            title = "Progress",
                            trailing = if (state.total == 0) null else "${state.completed.size} of ${state.total} done",
                        )
                        if (state.total > 0) {
                            Spacer(Modifier.height(12.dp))
                            ProgressBar(
                                progress = state.progress,
                                modifier = Modifier.padding(horizontal = 20.dp),
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                    }
                }

                if (state.total == 0) {
                    item(key = "empty") {
                        EmptyState(
                            title = "No goals for this month",
                            message = "Tap Add goal to set something you want to finish, learn or do.",
                        )
                    }
                }

                items(state.pending, key = { it.id }) { goal ->
                    GoalRow(
                        goal = goal,
                        onToggle = { viewModel.toggleGoal(goal) },
                        onEdit = { goalToEdit = goal },
                        onDelete = { goalToDelete = goal },
                        modifier = Modifier.animateItem(),
                    )
                }

                if (state.completed.isNotEmpty()) {
                    item(key = "completed-header") {
                        Text(
                            text = "Completed",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp),
                        )
                    }
                    items(state.completed, key = { it.id }) { goal ->
                        GoalRow(
                            goal = goal,
                            onToggle = { viewModel.toggleGoal(goal) },
                            onEdit = { goalToEdit = goal },
                            onDelete = { goalToDelete = goal },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }

        ExtendedFloatingActionButton(
            onClick = { showAddDialog = true },
            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
            text = { Text("Add goal") },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp),
        )
    }

    if (showAddDialog) {
        TwoFieldDialog(
            title = "New monthly goal",
            firstLabel = "Goal",
            secondLabel = "Notes (optional)",
            firstInitial = "",
            secondInitial = "",
            confirmLabel = "Add",
            requireFirst = true,
            onConfirm = { title, notes ->
                viewModel.addGoal(title, notes)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false },
        )
    }

    goalToEdit?.let { goal ->
        TwoFieldDialog(
            title = "Edit monthly goal",
            firstLabel = "Goal",
            secondLabel = "Notes (optional)",
            firstInitial = goal.title,
            secondInitial = goal.notes,
            confirmLabel = "Save",
            requireFirst = true,
            onConfirm = { title, notes ->
                viewModel.updateGoal(goal, title, notes)
                goalToEdit = null
            },
            onDismiss = { goalToEdit = null },
        )
    }

    goalToDelete?.let { goal ->
        ConfirmDialog(
            title = "Delete goal?",
            message = "\"${goal.title}\" will be deleted.",
            confirmLabel = "Delete",
            onConfirm = {
                viewModel.deleteGoal(goal)
                goalToDelete = null
            },
            onDismiss = { goalToDelete = null },
        )
    }
}

private fun monthCaption(state: MonthlyUiState): String? = when (state.month) {
    state.currentMonth -> "This month"
    state.currentMonth.minusMonths(1) -> "Last month"
    state.currentMonth.plusMonths(1) -> "Next month"
    else -> null
}

/** One monthly goal. Tap the row to complete or reopen it. */
@Composable
private fun GoalRow(
    goal: MonthlyGoal,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val done = goal.isCompleted
    Row(
        modifier = modifier
            .fillMaxWidth()
            .toggleable(value = done, role = Role.Checkbox, onValueChange = { onToggle() })
            .padding(start = 20.dp, end = 4.dp, top = 6.dp, bottom = 6.dp)
            .heightIn(min = 48.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CheckMark(checked = done)
        Spacer(Modifier.width(14.dp))
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 4.dp),
        ) {
            Text(
                text = goal.title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (done) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
            )
            if (goal.notes.isNotBlank()) {
                Text(
                    text = goal.notes,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        ItemMenu(onEdit = onEdit, onDelete = onDelete)
    }
}
