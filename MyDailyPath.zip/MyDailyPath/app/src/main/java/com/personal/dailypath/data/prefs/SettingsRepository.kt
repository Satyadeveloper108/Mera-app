package com.personal.dailypath.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

const val DEFAULT_APP_NAME = "My Daily Path"

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Personal settings and the spiritual-section details. */
data class AppSettings(
    val appName: String = DEFAULT_APP_NAME,
    val onboardingDone: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val spiritualEnabled: Boolean = true,
    val guruPhotoPath: String? = null,
    val guruName: String = "",
    val guruNote: String = "",
)

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(context: Context) {

    private val dataStore: DataStore<Preferences> = context.applicationContext.settingsDataStore

    private object Keys {
        val APP_NAME = stringPreferencesKey("app_name")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val SPIRITUAL_ENABLED = booleanPreferencesKey("spiritual_enabled")
        val GURU_PHOTO_PATH = stringPreferencesKey("guru_photo_path")
        val GURU_NAME = stringPreferencesKey("guru_name")
        val GURU_NOTE = stringPreferencesKey("guru_note")
    }

    val settings: Flow<AppSettings> = dataStore.data
        .catch { error ->
            if (error is IOException) emit(emptyPreferences()) else throw error
        }
        .map { prefs ->
            AppSettings(
                appName = prefs[Keys.APP_NAME] ?: DEFAULT_APP_NAME,
                onboardingDone = prefs[Keys.ONBOARDING_DONE] ?: false,
                themeMode = prefs[Keys.THEME_MODE]?.toThemeMode() ?: ThemeMode.SYSTEM,
                spiritualEnabled = prefs[Keys.SPIRITUAL_ENABLED] ?: true,
                guruPhotoPath = prefs[Keys.GURU_PHOTO_PATH],
                guruName = prefs[Keys.GURU_NAME].orEmpty(),
                guruNote = prefs[Keys.GURU_NOTE].orEmpty(),
            )
        }

    suspend fun completeOnboarding(appName: String) {
        dataStore.edit { prefs ->
            prefs[Keys.APP_NAME] = appName.trim().ifBlank { DEFAULT_APP_NAME }
            prefs[Keys.ONBOARDING_DONE] = true
        }
    }

    suspend fun setAppName(appName: String) {
        dataStore.edit { prefs ->
            prefs[Keys.APP_NAME] = appName.trim().ifBlank { DEFAULT_APP_NAME }
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { prefs -> prefs[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setSpiritualEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[Keys.SPIRITUAL_ENABLED] = enabled }
    }

    suspend fun setGuruPhotoPath(path: String?) {
        dataStore.edit { prefs ->
            prefs.remove(Keys.GURU_PHOTO_PATH)
            if (path != null) {
                prefs[Keys.GURU_PHOTO_PATH] = path
            }
        }
    }

    suspend fun setGuruDetails(name: String, note: String) {
        dataStore.edit { prefs ->
            prefs[Keys.GURU_NAME] = name.trim()
            prefs[Keys.GURU_NOTE] = note.trim()
        }
    }

    private fun String.toThemeMode(): ThemeMode =
        runCatching { ThemeMode.valueOf(this) }.getOrDefault(ThemeMode.SYSTEM)
}
