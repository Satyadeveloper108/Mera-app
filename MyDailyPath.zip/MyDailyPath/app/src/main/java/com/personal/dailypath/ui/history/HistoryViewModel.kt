package com.personal.dailypath.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.local.DailyGoal
import com.personal.dailypath.data.local.DailyTask
import com.personal.dailypath.data.local.MonthlyGoal
import com.personal.dailypath.domain.StreakCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import java.time.YearMonth

/** Everything recorded for one day: the main goal and that day's tasks. */
data class DayRecord(
    val date: LocalDate,
    val goal: DailyGoal?,
    val tasks: List<DailyTask>,
) {
    val tasksDone: Int get() = tasks.count { it.isCompleted }
}

/** Everything recorded for one month: the monthly goals plus a few totals. */
data class MonthRecord(
    val month: YearMonth,
    val goals: List<MonthlyGoal>,
    /** How many days in the month had their main goal completed. */
    val goalDays: Int,
    /** How many daily tasks were completed in the month. */
    val tasksDone: Int,
) {
    val goalsDone: Int get() = goals.count { it.isCompleted }
}

data class HistoryUiState(
    val isLoading: Boolean = true,
    val today: LocalDate = LocalDate.now(),
    val days: List<DayRecord> = emptyList(),
    val months: List<MonthRecord> = emptyList(),
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val goalsCompleted: Int = 0,
    val tasksCompleted: Int = 0,
)

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModel(container: AppContainer) : ViewModel() {

    private val repository = container.repository

    val uiState: StateFlow<HistoryUiState> = container.todayTracker.today
        .flatMapLatest { today ->
            combine(
                repository.observeAllTasks(),
                repository.observeAllGoals(),
                repository.observeAllMonthlyGoals(),
            ) { tasks, goals, monthlyGoals ->
                buildState(today, tasks, goals, monthlyGoals)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUiState())

    private fun buildState(
        today: LocalDate,
        tasks: List<DailyTask>,
        goals: List<DailyGoal>,
        monthlyGoals: List<MonthlyGoal>,
    ): HistoryUiState {
        val tasksByDate = tasks.groupBy { it.date }
        val goalsByDate = goals.associateBy { it.date }

        // Today and earlier. Tasks planned for the future are not history yet.
        val days = (tasksByDate.keys + goalsByDate.keys)
            .filter { !it.isAfter(today) }
            .sortedDescending()
            .map { date ->
                DayRecord(
                    date = date,
                    goal = goalsByDate[date],
                    tasks = tasksByDate[date].orEmpty(),
                )
            }

        val currentMonth = YearMonth.from(today)
        val monthlyGoalsByMonth = monthlyGoals.groupBy { it.month }
        val goalDaysByMonth = goals
            .filter { it.isCompleted }
            .groupingBy { YearMonth.from(it.date) }
            .eachCount()
        val tasksDoneByMonth = tasks
            .filter { it.isCompleted }
            .groupingBy { YearMonth.from(it.date) }
            .eachCount()
        val activityMonths = tasks.map { YearMonth.from(it.date) } + goals.map { YearMonth.from(it.date) }

        val months = (monthlyGoalsByMonth.keys + activityMonths)
            .filter { !it.isAfter(currentMonth) }
            .distinct()
            .sortedDescending()
            .map { month ->
                MonthRecord(
                    month = month,
                    goals = monthlyGoalsByMonth[month].orEmpty(),
                    goalDays = goalDaysByMonth[month] ?: 0,
                    tasksDone = tasksDoneByMonth[month] ?: 0,
                )
            }

        val completedDates = goals.filter { it.isCompleted }.map { it.date }.toSet()
        val streak = StreakCalculator.calculate(completedDates, today)

        return HistoryUiState(
            isLoading = false,
            today = today,
            days = days,
            months = months,
            currentStreak = streak.current,
            bestStreak = streak.best,
            goalsCompleted = completedDates.size,
            tasksCompleted = tasks.count { it.isCompleted },
        )
    }
}
