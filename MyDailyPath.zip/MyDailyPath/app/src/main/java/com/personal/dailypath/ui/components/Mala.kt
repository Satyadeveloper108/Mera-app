package com.personal.dailypath.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.personal.dailypath.domain.DayMark
import com.personal.dailypath.ui.theme.AppTheme
import java.util.Locale
import java.time.format.TextStyle as WeekdayStyle

/**
 * The last seven days as a string of prayer beads (a mala). A filled bead is a day
 * whose main goal was completed. Today's bead has a brighter ring.
 * Meant to sit on the main-goal panel.
 */
@Composable
fun MalaRow(
    days: List<DayMark>,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    val locale = Locale.getDefault()
    Box(modifier = modifier.fillMaxWidth()) {
        // The thread runs through the centre of the beads.
        Canvas(modifier = Modifier.matchParentSize()) {
            val y = 12.dp.toPx()
            drawLine(
                color = colors.beadOutline,
                start = Offset(12.dp.toPx(), y),
                end = Offset(size.width - 12.dp.toPx(), y),
                strokeWidth = 1.5.dp.toPx(),
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            days.forEach { mark ->
                Bead(
                    mark = mark,
                    label = mark.date.dayOfWeek.getDisplayName(WeekdayStyle.NARROW, locale),
                )
            }
        }
    }
}

@Composable
private fun Bead(
    mark: DayMark,
    label: String,
) {
    val colors = AppTheme.colors
    val fillScale by animateFloatAsState(
        targetValue = if (mark.completed) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow,
        ),
        label = "bead-fill",
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(modifier = Modifier.size(24.dp)) {
            val radius = size.minDimension / 2f
            // A solid base, so the thread does not show through the bead.
            drawCircle(color = colors.hero, radius = radius)
            drawCircle(
                color = if (mark.isToday) colors.onHero else colors.beadOutline,
                radius = radius - 1.dp.toPx(),
                style = Stroke(width = if (mark.isToday) 2.dp.toPx() else 1.5.dp.toPx()),
            )
            val fillRadius = (radius - 3.5.dp.toPx()).coerceAtLeast(0f) * fillScale
            if (fillRadius > 0f) {
                drawCircle(color = colors.bead, radius = fillRadius)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (mark.isToday) colors.onHero else colors.onHeroMuted,
            fontWeight = if (mark.isToday) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** A single small bead: filled when the day's goal was completed, an empty ring when it was not. */
@Composable
fun StatusBead(
    done: Boolean,
    modifier: Modifier = Modifier,
    diameter: Dp = 16.dp,
) {
    val fillColor = AppTheme.colors.bead
    val ringColor = MaterialTheme.colorScheme.outline
    Canvas(modifier = modifier.size(diameter)) {
        val radius = size.minDimension / 2f
        if (done) {
            drawCircle(color = fillColor, radius = radius)
        } else {
            drawCircle(
                color = ringColor,
                radius = radius - 1.dp.toPx(),
                style = Stroke(width = 1.5.dp.toPx()),
            )
        }
    }
}
