package com.personal.dailypath.domain

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Date text used across the screens, following the phone's language. */
object DateFormats {

    private fun formatter(pattern: String): DateTimeFormatter =
        DateTimeFormatter.ofPattern(pattern, Locale.getDefault())

    /** Sunday, 20 September */
    fun fullDate(date: LocalDate): String = formatter("EEEE, d MMMM").format(date)

    /** Sun, 20 Sep 2026 */
    fun shortDate(date: LocalDate): String = formatter("EEE, d MMM yyyy").format(date)

    /** September 2026 */
    fun monthYear(month: YearMonth): String = formatter("MMMM yyyy").format(month)

    /** September */
    fun monthName(month: YearMonth): String = formatter("MMMM").format(month)

    fun relativeDay(date: LocalDate, today: LocalDate): String = when (date) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        today.plusDays(1) -> "Tomorrow"
        else -> shortDate(date)
    }
}
