package com.personal.dailypath.ui.dashboard

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.data.local.DailyGoal
import com.personal.dailypath.data.local.DailyTask
import com.personal.dailypath.domain.DateFormats
import com.personal.dailypath.domain.DayMark
import com.personal.dailypath.domain.StreakInfo
import com.personal.dailypath.ui.components.ConfirmDialog
import com.personal.dailypath.ui.components.EmptyState
import com.personal.dailypath.ui.components.GuruImage
import com.personal.dailypath.ui.components.ItemMenu
import com.personal.dailypath.ui.components.MalaRow
import com.personal.dailypath.ui.components.ProgressBar
import com.personal.dailypath.ui.components.SectionHeader
import com.personal.dailypath.ui.components.TaskRow
import com.personal.dailypath.ui.components.TextInputDialog
import com.personal.dailypath.ui.rememberAppViewModelFactory
import com.personal.dailypath.ui.theme.AppTheme
import java.time.LocalDate

@Composable
fun DashboardScreen(
    onOpenMonthly: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenSpiritual: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var showGoalDialog by rememberSaveable { mutableStateOf(false) }
    var showAddTaskDialog by rememberSaveable { mutableStateOf(false) }
    var showRemoveGoalDialog by rememberSaveable { mutableStateOf(false) }
    var taskToEdit by remember { mutableStateOf<DailyTask?>(null) }
    var taskToDelete by remember { mutableStateOf<DailyTask?>(null) }

    if (state.isLoading) {
        Box(modifier = modifier.fillMaxSize())
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp),
        ) {
            item(key = "header") {
                DashboardHeader(
                    appName = state.appName,
                    date = state.today,
                    guruPhotoPath = if (state.showSpiritual) state.guruPhotoPath else null,
                    onOpenSpiritual = onOpenSpiritual,
                    onOpenSettings = onOpenSettings,
                )
            }

            item(key = "goal") {
                GoalPanel(
                    goal = state.goal,
                    streak = state.streak,
                    recentDays = state.recentDays,
                    onChooseGoal = { showGoalDialog = true },
                    onEditGoal = { showGoalDialog = true },
                    onToggleDone = { viewModel.toggleGoalCompleted() },
                    onRemoveGoal = { showRemoveGoalDialog = true },
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }

            item(key = "tasks-header") {
                Column(modifier = Modifier.padding(top = 32.dp)) {
                    SectionHeader(
                        title = "Today's tasks",
                        trailing = if (state.totalTasks == 0) {
                            null
                        } else {
                            "${state.completedTasks.size} of ${state.totalTasks} done"
                        },
                    )
                    if (state.totalTasks > 0) {
                        Spacer(Modifier.height(12.dp))
                        ProgressBar(
                            progress = state.taskProgress,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                        Spacer(Modifier.height(4.dp))
                    }
                }
            }

            if (state.totalTasks == 0) {
                item(key = "tasks-empty") {
                    EmptyState(
                        title = "No tasks for today",
                        message = "Add the things you want to get done today.",
                    )
                }
            }

            items(state.pendingTasks, key = { it.id }) { task ->
                TaskRow(
                    task = task,
                    onToggle = { viewModel.toggleTask(task) },
                    onEdit = { taskToEdit = task },
                    onDelete = { taskToDelete = task },
                    modifier = Modifier.animateItem(),
                )
            }

            if (state.completedTasks.isNotEmpty()) {
                item(key = "completed-header") {
                    Text(
                        text = "Completed",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp),
                    )
                }
                items(state.completedTasks, key = { it.id }) { task ->
                    TaskRow(
                        task = task,
                        onToggle = { viewModel.toggleTask(task) },
                        onEdit = { taskToEdit = task },
                        onDelete = { taskToDelete = task },
                        modifier = Modifier.animateItem(),
                    )
                }
            }

            item(key = "add-task") {
                TextButton(
                    onClick = { showAddTaskDialog = true },
                    modifier = Modifier.padding(horizontal = 12.dp),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Add task")
                }
            }

            item(key = "month") {
                MonthSnapshot(
                    monthName = state.monthName,
                    done = state.monthGoalsDone,
                    total = state.monthGoalsTotal,
                    onClick = onOpenMonthly,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 28.dp),
                )
            }
        }
    }

    if (showGoalDialog) {
        val hasGoal = state.goal != null
        TextInputDialog(
            title = if (hasGoal) "Edit main goal" else "Main goal for today",
            label = "Goal",
            initialValue = state.goal?.title.orEmpty(),
            confirmLabel = if (hasGoal) "Save" else "Set goal",
            supportingText = if (hasGoal) null else "Pick the one thing that would make today a success.",
            onConfirm = { text ->
                viewModel.saveGoal(text)
                showGoalDialog = false
            },
            onDismiss = { showGoalDialog = false },
        )
    }

    if (showAddTaskDialog) {
        TextInputDialog(
            title = "New task",
            label = "Task",
            initialValue = "",
            confirmLabel = "Add",
            onConfirm = { text ->
                viewModel.addTask(text)
                showAddTaskDialog = false
            },
            onDismiss = { showAddTaskDialog = false },
        )
    }

    if (showRemoveGoalDialog) {
        ConfirmDialog(
            title = "Remove main goal?",
            message = "Today's main goal will be cleared. You can choose a new one afterwards.",
            confirmLabel = "Remove",
            onConfirm = {
                viewModel.removeGoal()
                showRemoveGoalDialog = false
            },
            onDismiss = { showRemoveGoalDialog = false },
        )
    }

    taskToEdit?.let { task ->
        TextInputDialog(
            title = "Edit task",
            label = "Task",
            initialValue = task.title,
            confirmLabel = "Save",
            onConfirm = { text ->
                viewModel.renameTask(task, text)
                taskToEdit = null
            },
            onDismiss = { taskToEdit = null },
        )
    }

    taskToDelete?.let { task ->
        ConfirmDialog(
            title = "Delete task?",
            message = "\"${task.title}\" will be deleted.",
            confirmLabel = "Delete",
            onConfirm = {
                viewModel.deleteTask(task)
                taskToDelete = null
            },
            onDismiss = { taskToDelete = null },
        )
    }
}

@Composable
private fun DashboardHeader(
    appName: String,
    date: LocalDate,
    guruPhotoPath: String?,
    onOpenSpiritual: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 16.dp, bottom = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = appName,
                style = MaterialTheme.typography.headlineMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = DateFormats.fullDate(date),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (guruPhotoPath != null) {
            GuruImage(
                path = guruPhotoPath,
                contentDescription = "Open the Guru section",
                maxSidePx = 240,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClickLabel = "Open the Guru section", onClick = onOpenSpiritual),
            )
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = "Settings")
        }
    }
}

/** The main goal for today, with the streak and the last seven days. The one bold block on this screen. */
@Composable
private fun GoalPanel(
    goal: DailyGoal?,
    streak: StreakInfo,
    recentDays: List<DayMark>,
    onChooseGoal: () -> Unit,
    onEditGoal: () -> Unit,
    onToggleDone: () -> Unit,
    onRemoveGoal: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(colors.hero)
            .padding(start = 22.dp, end = 12.dp, top = 22.dp, bottom = 14.dp),
    ) {
        Text(
            text = "Main goal for today",
            style = MaterialTheme.typography.labelLarge,
            color = colors.onHeroMuted,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = goal?.title ?: "Choose the one thing that matters most today.",
            style = MaterialTheme.typography.headlineSmall,
            color = colors.onHero,
            modifier = Modifier.padding(end = 10.dp),
        )
        Spacer(Modifier.height(22.dp))
        StreakBlock(
            streak = streak,
            recentDays = recentDays,
            modifier = Modifier.padding(end = 10.dp),
        )
        Spacer(Modifier.height(18.dp))
        GoalActions(
            goal = goal,
            onChooseGoal = onChooseGoal,
            onEditGoal = onEditGoal,
            onToggleDone = onToggleDone,
            onRemoveGoal = onRemoveGoal,
        )
    }
}

@Composable
private fun StreakBlock(
    streak: StreakInfo,
    recentDays: List<DayMark>,
    modifier: Modifier = Modifier,
) {
    val colors = AppTheme.colors
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.Bottom) {
            AnimatedContent(
                targetState = streak.current,
                transitionSpec = {
                    (slideInVertically { height -> height / 2 } + fadeIn()) togetherWith
                        (slideOutVertically { height -> -height / 2 } + fadeOut())
                },
                label = "streak-count",
            ) { count ->
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.displayLarge,
                    color = colors.onHero,
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.padding(bottom = 12.dp)) {
                Text(
                    text = "day streak",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.onHero,
                )
                Text(
                    text = "Longest: ${streak.best} ${if (streak.best == 1) "day" else "days"}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.onHeroMuted,
                )
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = streakMessage(streak),
            style = MaterialTheme.typography.bodyMedium,
            color = colors.onHeroMuted,
        )
        Spacer(Modifier.height(16.dp))
        MalaRow(days = recentDays)
    }
}

private fun streakMessage(streak: StreakInfo): String = when {
    streak.completedToday -> "Completed today. Come back tomorrow to continue the streak."
    streak.current > 0 -> "Complete today's goal to continue your streak."
    else -> "Complete today's goal to start a streak."
}

@Composable
private fun GoalActions(
    goal: DailyGoal?,
    onChooseGoal: () -> Unit,
    onEditGoal: () -> Unit,
    onToggleDone: () -> Unit,
    onRemoveGoal: () -> Unit,
) {
    val colors = AppTheme.colors
    val accentButton = ButtonDefaults.buttonColors(
        containerColor = colors.bead,
        contentColor = colors.onBead,
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        when {
            goal == null -> {
                Button(
                    onClick = onChooseGoal,
                    colors = accentButton,
                    shape = RoundedCornerShape(50),
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Choose main goal")
                }
            }

            goal.isCompleted -> {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.bead)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = null,
                        tint = colors.onBead,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Completed",
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.onBead,
                    )
                }
                Spacer(Modifier.width(4.dp))
                TextButton(
                    onClick = onToggleDone,
                    colors = ButtonDefaults.textButtonColors(contentColor = colors.onHero),
                ) {
                    Text("Undo")
                }
            }

            else -> {
                Button(
                    onClick = onToggleDone,
                    colors = accentButton,
                    shape = RoundedCornerShape(50),
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Mark as done")
                }
            }
        }

        if (goal != null) {
            Spacer(Modifier.weight(1f))
            ItemMenu(
                onEdit = onEditGoal,
                onDelete = onRemoveGoal,
                tint = colors.onHero,
                deleteLabel = "Remove",
                showDelete = !goal.isCompleted,
            )
        }
    }
}

@Composable
private fun MonthSnapshot(
    monthName: String,
    done: Int,
    total: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .clickable(onClick = onClick)
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$monthName goals",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Spacer(Modifier.height(6.dp))
        if (total == 0) {
            Text(
                text = "No goals set for this month yet. Tap to add one.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            Text(
                text = "$done of $total completed",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            ProgressBar(progress = done.toFloat() / total)
        }
    }
}
