package com.personal.dailypath.data.local

import androidx.room.TypeConverter
import java.time.LocalDate
import java.time.YearMonth

/**
 * Dates are stored as ISO text (yyyy-MM-dd and yyyy-MM). ISO text sorts in
 * calendar order, which keeps the SQL queries simple.
 */
class Converters {

    @TypeConverter
    fun fromLocalDate(value: LocalDate?): String? = value?.toString()

    @TypeConverter
    fun toLocalDate(value: String?): LocalDate? = value?.let { LocalDate.parse(it) }

    @TypeConverter
    fun fromYearMonth(value: YearMonth?): String? = value?.toString()

    @TypeConverter
    fun toYearMonth(value: String?): YearMonth? = value?.let { YearMonth.parse(it) }
}
