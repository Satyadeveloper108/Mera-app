package com.personal.dailypath.ui.monthly

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.local.MonthlyGoal
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth

data class MonthlyUiState(
    val isLoading: Boolean = true,
    val month: YearMonth = YearMonth.now(),
    val currentMonth: YearMonth = YearMonth.now(),
    val pending: List<MonthlyGoal> = emptyList(),
    val completed: List<MonthlyGoal> = emptyList(),
) {
    val total: Int get() = pending.size + completed.size

    val progress: Float get() = if (total == 0) 0f else completed.size.toFloat() / total
}

@OptIn(ExperimentalCoroutinesApi::class)
class MonthlyViewModel(container: AppContainer) : ViewModel() {

    private val repository = container.repository
    private val tracker = container.todayTracker

    /** The month the person chose to look at. Null means "follow the current month". */
    private val selectedMonth = MutableStateFlow<YearMonth?>(null)

    val uiState: StateFlow<MonthlyUiState> = combine(selectedMonth, tracker.today) { selected, today ->
        val current = YearMonth.from(today)
        (selected ?: current) to current
    }
        .flatMapLatest { (month, current) ->
            repository.observeMonthlyGoals(month).map { goals ->
                MonthlyUiState(
                    isLoading = false,
                    month = month,
                    currentMonth = current,
                    pending = goals.filter { !it.isCompleted },
                    completed = goals.filter { it.isCompleted },
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), MonthlyUiState())

    private fun currentMonth(): YearMonth = YearMonth.from(tracker.today.value)

    private fun shownMonth(): YearMonth = selectedMonth.value ?: currentMonth()

    fun showPreviousMonth() {
        val previous = shownMonth().minusMonths(1)
        selectedMonth.value = if (previous == currentMonth()) null else previous
    }

    fun showNextMonth() {
        val next = shownMonth().plusMonths(1)
        selectedMonth.value = if (next == currentMonth()) null else next
    }

    fun showCurrentMonth() {
        selectedMonth.value = null
    }

    fun addGoal(title: String, notes: String) {
        val month = shownMonth()
        viewModelScope.launch { repository.addMonthlyGoal(title, notes, month) }
    }

    fun updateGoal(goal: MonthlyGoal, title: String, notes: String) {
        viewModelScope.launch { repository.updateMonthlyGoal(goal.id, title, notes) }
    }

    fun toggleGoal(goal: MonthlyGoal) {
        viewModelScope.launch { repository.setMonthlyGoalCompleted(goal.id, !goal.isCompleted) }
    }

    fun deleteGoal(goal: MonthlyGoal) {
        viewModelScope.launch { repository.deleteMonthlyGoal(goal.id) }
    }
}
