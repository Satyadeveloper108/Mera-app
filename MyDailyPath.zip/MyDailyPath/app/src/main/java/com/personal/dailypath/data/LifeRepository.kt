package com.personal.dailypath.data

import com.personal.dailypath.data.local.DailyGoal
import com.personal.dailypath.data.local.DailyGoalDao
import com.personal.dailypath.data.local.DailyTask
import com.personal.dailypath.data.local.DailyTaskDao
import com.personal.dailypath.data.local.MonthlyGoal
import com.personal.dailypath.data.local.MonthlyGoalDao
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import java.time.YearMonth

/** The one place the screens go through to read and change tasks and goals. */
class LifeRepository(
    private val taskDao: DailyTaskDao,
    private val goalDao: DailyGoalDao,
    private val monthlyGoalDao: MonthlyGoalDao,
) {

    // ---- Daily tasks ---------------------------------------------------------------------

    fun observeTasks(date: LocalDate): Flow<List<DailyTask>> = taskDao.observeForDate(date)

    fun observeAllTasks(): Flow<List<DailyTask>> = taskDao.observeAll()

    suspend fun addTask(title: String, date: LocalDate) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        taskDao.insert(DailyTask(title = clean, date = date))
    }

    suspend fun renameTask(taskId: Long, title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        taskDao.updateTitle(taskId, clean)
    }

    suspend fun setTaskCompleted(taskId: Long, completed: Boolean) {
        taskDao.setCompleted(taskId, completed, if (completed) System.currentTimeMillis() else null)
    }

    suspend fun deleteTask(taskId: Long) {
        taskDao.deleteById(taskId)
    }

    // ---- Main daily goal -----------------------------------------------------------------

    fun observeAllGoals(): Flow<List<DailyGoal>> = goalDao.observeAll()

    /** Sets the main goal for [date], or renames it if one already exists. Completion state is kept. */
    suspend fun saveGoal(date: LocalDate, title: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        goalDao.insertIfAbsent(DailyGoal(date = date, title = clean))
        goalDao.updateTitle(date, clean)
    }

    /** Safe to call any number of times: a day is only ever marked once. */
    suspend fun setGoalCompleted(date: LocalDate, completed: Boolean) {
        goalDao.setCompleted(date, completed, if (completed) System.currentTimeMillis() else null)
    }

    suspend fun removeGoal(date: LocalDate) {
        goalDao.deleteIfNotCompleted(date)
    }

    // ---- Monthly goals -------------------------------------------------------------------

    fun observeMonthlyGoals(month: YearMonth): Flow<List<MonthlyGoal>> = monthlyGoalDao.observeForMonth(month)

    fun observeAllMonthlyGoals(): Flow<List<MonthlyGoal>> = monthlyGoalDao.observeAll()

    suspend fun addMonthlyGoal(title: String, notes: String, month: YearMonth) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        monthlyGoalDao.insert(MonthlyGoal(title = clean, notes = notes.trim(), month = month))
    }

    suspend fun updateMonthlyGoal(goalId: Long, title: String, notes: String) {
        val clean = title.trim()
        if (clean.isEmpty()) return
        monthlyGoalDao.updateDetails(goalId, clean, notes.trim())
    }

    suspend fun setMonthlyGoalCompleted(goalId: Long, completed: Boolean) {
        monthlyGoalDao.setCompleted(goalId, completed, if (completed) System.currentTimeMillis() else null)
    }

    suspend fun deleteMonthlyGoal(goalId: Long) {
        monthlyGoalDao.deleteById(goalId)
    }
}
