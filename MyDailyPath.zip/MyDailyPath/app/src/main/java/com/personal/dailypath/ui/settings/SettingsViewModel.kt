package com.personal.dailypath.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.personal.dailypath.AppContainer
import com.personal.dailypath.data.prefs.AppSettings
import com.personal.dailypath.data.prefs.ThemeMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(container: AppContainer) : ViewModel() {

    private val repository = container.settingsRepository

    val settings: StateFlow<AppSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    fun setAppName(name: String) {
        viewModelScope.launch { repository.setAppName(name) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setSpiritualEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setSpiritualEnabled(enabled) }
    }
}
