package com.personal.dailypath.ui.theme

import androidx.compose.ui.graphics.Color

// The palette comes from the subject: tulsi (holy basil) greens, marigold garlands and temple ash.

// Light theme
internal val Tulsi = Color(0xFF1F5A47)
internal val TulsiMist = Color(0xFFD3E9DD)
internal val TulsiInk = Color(0xFF0E3325)
internal val Marigold = Color(0xFFEBAA1F)
internal val MarigoldSoft = Color(0xFFFBE4A8)
internal val MarigoldInk = Color(0xFF3A2700)
internal val Ash = Color(0xFFF1F4EF)
internal val Ink = Color(0xFF18261F)
internal val InkMuted = Color(0xFF515F58)
internal val Brick = Color(0xFFB3382C)

// Dark theme
internal val NightGreen = Color(0xFF0F1815)
internal val NightTulsi = Color(0xFF8FD3B6)
internal val NightTulsiContainer = Color(0xFF1C4F3D)
internal val NightMarigold = Color(0xFFF2BE4F)
internal val NightInk = Color(0xFFE1EAE5)
internal val NightInkMuted = Color(0xFFA6B5AE)
