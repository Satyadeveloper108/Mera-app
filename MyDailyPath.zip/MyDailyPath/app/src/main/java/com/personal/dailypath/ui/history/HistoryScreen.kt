package com.personal.dailypath.ui.history

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.personal.dailypath.domain.DateFormats
import com.personal.dailypath.ui.components.CheckMark
import com.personal.dailypath.ui.components.EmptyState
import com.personal.dailypath.ui.components.ProgressBar
import com.personal.dailypath.ui.components.ScreenHeader
import com.personal.dailypath.ui.components.SegmentedToggle
import com.personal.dailypath.ui.components.StatusBead
import com.personal.dailypath.ui.rememberAppViewModelFactory
import java.time.LocalDate

/** Read-only record of previous days and months. Tap an entry to see what was in it. */
@Composable
fun HistoryScreen(
    modifier: Modifier = Modifier,
    viewModel: HistoryViewModel = viewModel(factory = rememberAppViewModelFactory()),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    var tab by rememberSaveable { mutableStateOf(0) }
    var expandedKey by rememberSaveable { mutableStateOf<String?>(null) }

    if (state.isLoading) {
        Box(modifier = modifier.fillMaxSize())
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        item(key = "header") {
            ScreenHeader(
                title = "History",
                subtitle = "What you have completed on earlier days and months.",
            )
        }

        item(key = "summary") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                SummaryStat(value = state.bestStreak, label = "Longest streak", modifier = Modifier.weight(1f))
                SummaryStat(value = state.goalsCompleted, label = "Goals completed", modifier = Modifier.weight(1f))
                SummaryStat(value = state.tasksCompleted, label = "Tasks completed", modifier = Modifier.weight(1f))
            }
        }

        item(key = "toggle") {
            SegmentedToggle(
                options = listOf("Days", "Months"),
                selectedIndex = tab,
                onSelect = { selected ->
                    tab = selected
                    expandedKey = null
                },
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp),
            )
        }

        if (tab == 0) {
            if (state.days.isEmpty()) {
                item(key = "days-empty") {
                    EmptyState(
                        title = "Nothing recorded yet",
                        message = "Completed tasks and goals from each day will appear here.",
                    )
                }
            }
            items(state.days, key = { "day-${it.date}" }) { record ->
                val entryKey = "day-${record.date}"
                DayEntry(
                    record = record,
                    today = state.today,
                    expanded = expandedKey == entryKey,
                    onClick = { expandedKey = if (expandedKey == entryKey) null else entryKey },
                )
            }
        } else {
            if (state.months.isEmpty()) {
                item(key = "months-empty") {
                    EmptyState(
                        title = "Nothing recorded yet",
                        message = "Your monthly goals and totals for each month will appear here.",
                    )
                }
            }
            items(state.months, key = { "month-${it.month}" }) { record ->
                val entryKey = "month-${record.month}"
                MonthEntry(
                    record = record,
                    expanded = expandedKey == entryKey,
                    onClick = { expandedKey = if (expandedKey == entryKey) null else entryKey },
                )
            }
        }
    }
}

@Composable
private fun SummaryStat(
    value: Int,
    label: String,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier) {
        Text(text = value.toString(), style = MaterialTheme.typography.headlineLarge)
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun DayEntry(
    record: DayRecord,
    today: LocalDate,
    expanded: Boolean,
    onClick: () -> Unit,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusBead(done = record.goal?.isCompleted == true)
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = DateFormats.relativeDay(record.date, today),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = daySummary(record),
                    style = MaterialTheme.typography.bodyMedium,
                    color = muted,
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (expanded) "Hide details" else "Show details",
                tint = muted,
            )
        }
        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(start = 30.dp, top = 12.dp)) {
                if (record.goal != null) {
                    Text(text = "Main goal", style = MaterialTheme.typography.labelLarge, color = muted)
                    Text(text = record.goal.title, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(12.dp))
                }
                if (record.tasks.isEmpty()) {
                    Text(
                        text = "No tasks were recorded for this day.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                    )
                } else {
                    Text(text = "Tasks", style = MaterialTheme.typography.labelLarge, color = muted)
                    Spacer(Modifier.height(4.dp))
                    record.tasks.forEach { task ->
                        HistoryLine(text = task.title, done = task.isCompleted)
                    }
                }
            }
        }
    }
}

private fun daySummary(record: DayRecord): String {
    val goalLine = when {
        record.goal == null -> "No main goal"
        record.goal.isCompleted -> "Main goal completed"
        else -> "Main goal not completed"
    }
    return if (record.tasks.isEmpty()) {
        goalLine
    } else {
        "$goalLine\n${record.tasksDone} of ${record.tasks.size} tasks done"
    }
}

@Composable
private fun MonthEntry(
    record: MonthRecord,
    expanded: Boolean,
    onClick: () -> Unit,
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = DateFormats.monthYear(record.month),
                    style = MaterialTheme.typography.titleMedium,
                )
                Text(
                    text = monthSummary(record),
                    style = MaterialTheme.typography.bodyMedium,
                    color = muted,
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (expanded) "Hide details" else "Show details",
                tint = muted,
            )
        }
        if (record.goals.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            ProgressBar(progress = record.goalsDone.toFloat() / record.goals.size)
        }
        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 12.dp)) {
                if (record.goals.isEmpty()) {
                    Text(
                        text = "No monthly goals were set for this month.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                    )
                } else {
                    Text(text = "Monthly goals", style = MaterialTheme.typography.labelLarge, color = muted)
                    Spacer(Modifier.height(4.dp))
                    record.goals.forEach { goal ->
                        HistoryLine(text = goal.title, done = goal.isCompleted)
                    }
                }
            }
        }
    }
}

private fun monthSummary(record: MonthRecord): String {
    val goals = if (record.goals.isEmpty()) {
        "No monthly goals"
    } else {
        "${record.goalsDone} of ${record.goals.size} monthly goals completed"
    }
    val days = "Main goal completed on ${record.goalDays} ${if (record.goalDays == 1) "day" else "days"}"
    val tasks = "${record.tasksDone} ${if (record.tasksDone == 1) "task" else "tasks"} completed"
    return "$goals\n$days\n$tasks"
}

/** One line in an expanded entry: a small check and the text. */
@Composable
private fun HistoryLine(
    text: String,
    done: Boolean,
) {
    Row(
        modifier = Modifier.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CheckMark(checked = done, diameter = 20.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = if (done) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
