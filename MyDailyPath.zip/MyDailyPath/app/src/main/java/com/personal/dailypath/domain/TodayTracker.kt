package com.personal.dailypath.domain

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/**
 * Holds "today" so every screen agrees on the current day, and so the dashboard
 * moves on to the new day by itself when midnight passes while the app is open.
 */
class TodayTracker {

    private val _today = MutableStateFlow(LocalDate.now())
    val today: StateFlow<LocalDate> = _today.asStateFlow()

    /** Re-reads the phone's date. Does nothing if the day has not changed. */
    fun refresh() {
        _today.value = LocalDate.now()
    }
}
