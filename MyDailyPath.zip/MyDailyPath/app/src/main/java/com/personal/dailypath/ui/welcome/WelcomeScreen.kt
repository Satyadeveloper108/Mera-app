package com.personal.dailypath.ui.welcome

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.personal.dailypath.data.prefs.DEFAULT_APP_NAME
import com.personal.dailypath.domain.DayMark
import com.personal.dailypath.ui.components.MalaRow
import com.personal.dailypath.ui.theme.AppTheme
import java.time.LocalDate

private const val MAX_APP_NAME_LENGTH = 40

/** Shown once, the first time the app opens: choose what to call the app. */
@Composable
fun WelcomeScreen(onStart: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf(DEFAULT_APP_NAME) }
    val canStart = name.isNotBlank()

    // A sample week, to show what the streak beads look like.
    val sampleDays = remember {
        val today = LocalDate.now()
        (6 downTo 0).map { offset ->
            DayMark(
                date = today.minusDays(offset.toLong()),
                completed = offset > 0,
                isToday = offset == 0,
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .systemBarsPadding()
            .imePadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(AppTheme.colors.hero)
                    .padding(24.dp),
            ) {
                MalaRow(days = sampleDays)
            }

            Spacer(Modifier.height(32.dp))
            Text(text = "Welcome", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Give your daily companion a name. You can change it later in Settings.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { if (it.length <= MAX_APP_NAME_LENGTH) name = it },
                label = { Text("App name") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Words,
                    imeAction = ImeAction.Done,
                ),
                keyboardActions = KeyboardActions(onDone = { if (canStart) onStart(name.trim()) }),
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(12.dp))
            Text(
                text = "Everything you enter stays on this phone. No account or internet connection is needed.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { onStart(name.trim()) },
                enabled = canStart,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("Get started")
            }
        }
    }
}
