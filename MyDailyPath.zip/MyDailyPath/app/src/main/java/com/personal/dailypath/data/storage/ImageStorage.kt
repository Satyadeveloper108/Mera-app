package com.personal.dailypath.data.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Keeps the chosen photo inside the app's private storage.
 *
 * A picture picked from the gallery is only readable for a short time, so the photo
 * is copied (resized, and rotated upright) into the app's own folder. After that it
 * stays available offline, even if the original is moved or deleted from the gallery.
 */
class ImageStorage(context: Context) {

    private val appContext = context.applicationContext
    private val photoDir: File get() = File(appContext.filesDir, "guru").apply { mkdirs() }

    /** Copies the picture at [uri] into private storage. Returns the new file path, or null if it could not be read. */
    suspend fun savePhoto(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val resolver = appContext.contentResolver

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null

            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, MAX_SIDE_PX)
            }
            val decoded = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                ?: return@withContext null

            val orientation = resolver.openInputStream(uri)?.use { stream ->
                ExifInterface(stream).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            } ?: ExifInterface.ORIENTATION_NORMAL

            val upright = applyOrientation(decoded, orientation)
            val target = File(photoDir, "photo_${System.currentTimeMillis()}.jpg")
            FileOutputStream(target).use { output ->
                upright.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)
            }
            target.absolutePath
        } catch (error: Exception) {
            null
        } catch (error: OutOfMemoryError) {
            null
        }
    }

    /** Deletes a photo previously saved by [savePhoto]. Files outside the photo folder are never touched. */
    suspend fun deletePhoto(path: String?) {
        if (path == null) return
        withContext(Dispatchers.IO) {
            val file = File(path)
            if (file.parentFile?.canonicalPath == photoDir.canonicalPath) {
                file.delete()
            }
        }
    }

    private fun applyOrientation(source: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(-90f)
                matrix.postScale(-1f, 1f)
            }
            else -> return source
        }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    companion object {
        private const val MAX_SIDE_PX = 1600
        private const val JPEG_QUALITY = 90

        private fun sampleSizeFor(width: Int, height: Int, maxSide: Int): Int {
            var sample = 1
            var w = width
            var h = height
            while (w / 2 >= maxSide || h / 2 >= maxSide) {
                w /= 2
                h /= 2
                sample *= 2
            }
            return sample
        }

        /** Loads a saved photo at roughly [maxSidePx] on its longest side, to keep memory use small. */
        fun decodeForDisplay(path: String, maxSidePx: Int): Bitmap? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val options = BitmapFactory.Options().apply {
                inSampleSize = sampleSizeFor(bounds.outWidth, bounds.outHeight, maxSidePx)
            }
            return try {
                BitmapFactory.decodeFile(path, options)
            } catch (error: OutOfMemoryError) {
                null
            }
        }
    }
}
